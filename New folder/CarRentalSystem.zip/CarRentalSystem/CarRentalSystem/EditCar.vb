﻿Public Class EditCar
    Private Sub EditCar_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class