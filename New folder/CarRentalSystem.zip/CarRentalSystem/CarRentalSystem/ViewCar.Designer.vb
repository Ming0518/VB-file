﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ViewCar
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Button2 = New Button()
        Label11 = New Label()
        UPCar = New Button()
        Label10 = New Label()
        Label9 = New Label()
        TextBox7 = New TextBox()
        Label8 = New Label()
        TextBox6 = New TextBox()
        Label7 = New Label()
        Label6 = New Label()
        Label18 = New Label()
        TextBox5 = New TextBox()
        TextBox4 = New TextBox()
        Label1 = New Label()
        Label5 = New Label()
        Label2 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        TextBox3 = New TextBox()
        TextBox1 = New TextBox()
        TextBox2 = New TextBox()
        Button1 = New Button()
        Button3 = New Button()
        Label12 = New Label()
        TextBox8 = New TextBox()
        SuspendLayout()
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(641, 391)
        Button2.Name = "Button2"
        Button2.Size = New Size(107, 47)
        Button2.TabIndex = 66
        Button2.Text = "Back"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Location = New Point(505, 287)
        Label11.Name = "Label11"
        Label11.Size = New Size(149, 20)
        Label11.TabIndex = 62
        Label11.Text = "Car Insurance Picture:"
        ' 
        ' UPCar
        ' 
        UPCar.Location = New Point(142, 279)
        UPCar.Name = "UPCar"
        UPCar.Size = New Size(94, 29)
        UPCar.TabIndex = 61
        UPCar.Text = "Download"
        UPCar.UseVisualStyleBackColor = True
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Location = New Point(263, 287)
        Label10.Name = "Label10"
        Label10.Size = New Size(123, 20)
        Label10.TabIndex = 60
        Label10.Text = "Car Grant Picture:"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Location = New Point(53, 283)
        Label9.Name = "Label9"
        Label9.Size = New Size(83, 20)
        Label9.TabIndex = 59
        Label9.Text = "Car Picture:"
        ' 
        ' TextBox7
        ' 
        TextBox7.Location = New Point(536, 175)
        TextBox7.Name = "TextBox7"
        TextBox7.Size = New Size(212, 27)
        TextBox7.TabIndex = 58
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Location = New Point(398, 214)
        Label8.Name = "Label8"
        Label8.Size = New Size(124, 20)
        Label8.TabIndex = 57
        Label8.Text = "Car Insurance No:"
        ' 
        ' TextBox6
        ' 
        TextBox6.Location = New Point(163, 211)
        TextBox6.Name = "TextBox6"
        TextBox6.Size = New Size(193, 27)
        TextBox6.TabIndex = 56
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(52, 211)
        Label7.Name = "Label7"
        Label7.Size = New Size(98, 20)
        Label7.TabIndex = 55
        Label7.Text = "Car Grant No:"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(380, 352)
        Label6.Name = "Label6"
        Label6.Size = New Size(157, 20)
        Label6.TabIndex = 52
        Label6.Text = "Rental price per hours:"
        ' 
        ' Label18
        ' 
        Label18.AutoSize = True
        Label18.Font = New Font("Stencil", 16.2F, FontStyle.Bold, GraphicsUnit.Point)
        Label18.Location = New Point(60, 60)
        Label18.Name = "Label18"
        Label18.Size = New Size(150, 33)
        Label18.TabIndex = 54
        Label18.Text = "View Car"
        ' 
        ' TextBox5
        ' 
        TextBox5.Location = New Point(555, 345)
        TextBox5.Name = "TextBox5"
        TextBox5.Size = New Size(193, 27)
        TextBox5.TabIndex = 51
        ' 
        ' TextBox4
        ' 
        TextBox4.Location = New Point(536, 214)
        TextBox4.Name = "TextBox4"
        TextBox4.Size = New Size(212, 27)
        TextBox4.TabIndex = 50
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Stencil", 22.2F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.Location = New Point(230, 7)
        Label1.Name = "Label1"
        Label1.Size = New Size(400, 44)
        Label1.TabIndex = 53
        Label1.Text = "Car Rental System"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(479, 175)
        Label5.Name = "Label5"
        Label5.Size = New Size(43, 20)
        Label5.TabIndex = 49
        Label5.Text = "Gear:"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(82, 124)
        Label2.Name = "Label2"
        Label2.Size = New Size(78, 20)
        Label2.TabIndex = 43
        Label2.Text = "Car Name:"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(475, 128)
        Label4.Name = "Label4"
        Label4.Size = New Size(47, 20)
        Label4.TabIndex = 48
        Label4.Text = "Seats:"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(119, 175)
        Label3.Name = "Label3"
        Label3.Size = New Size(31, 20)
        Label3.TabIndex = 45
        Label3.Text = "C.c:"
        ' 
        ' TextBox3
        ' 
        TextBox3.Location = New Point(536, 128)
        TextBox3.Name = "TextBox3"
        TextBox3.Size = New Size(212, 27)
        TextBox3.TabIndex = 47
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(163, 121)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(193, 27)
        TextBox1.TabIndex = 44
        ' 
        ' TextBox2
        ' 
        TextBox2.Location = New Point(163, 168)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(193, 27)
        TextBox2.TabIndex = 46
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(392, 283)
        Button1.Name = "Button1"
        Button1.Size = New Size(94, 29)
        Button1.TabIndex = 67
        Button1.Text = "Download"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Location = New Point(654, 283)
        Button3.Name = "Button3"
        Button3.Size = New Size(94, 29)
        Button3.TabIndex = 68
        Button3.Text = "Download"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Location = New Point(53, 345)
        Label12.Name = "Label12"
        Label12.Size = New Size(52, 20)
        Label12.TabIndex = 69
        Label12.Text = "Status:"
        ' 
        ' TextBox8
        ' 
        TextBox8.Location = New Point(119, 345)
        TextBox8.Name = "TextBox8"
        TextBox8.Size = New Size(193, 27)
        TextBox8.TabIndex = 70
        ' 
        ' ViewCar
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(TextBox8)
        Controls.Add(Label12)
        Controls.Add(Button3)
        Controls.Add(Button1)
        Controls.Add(Button2)
        Controls.Add(Label11)
        Controls.Add(UPCar)
        Controls.Add(Label10)
        Controls.Add(Label9)
        Controls.Add(TextBox7)
        Controls.Add(Label8)
        Controls.Add(TextBox6)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(Label18)
        Controls.Add(TextBox5)
        Controls.Add(TextBox4)
        Controls.Add(Label1)
        Controls.Add(Label5)
        Controls.Add(Label2)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(TextBox3)
        Controls.Add(TextBox1)
        Controls.Add(TextBox2)
        Name = "ViewCar"
        Text = "ViewCar"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Button2 As Button
    Friend WithEvents Label11 As Label
    Friend WithEvents UPCar As Button
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Label12 As Label
    Friend WithEvents TextBox8 As TextBox
End Class
